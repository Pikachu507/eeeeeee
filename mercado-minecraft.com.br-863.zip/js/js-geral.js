function goTo(str, boolean) {
    if (boolean) {
        return window.open(str, "_blank");
    }
    window.location.href = str;
}

$('.cardFeatures').hover(function () {

    $(this).find("ion-icon").attr('name', $(this).find("ion-icon").attr('name').replace('-outline', ''));

}, function () {

    $(this).find("ion-icon").attr('name', $(this).find("ion-icon").attr('name') + '-outline');

});

$('.cardFeatures').click(function () {

    var text = ""
    switch ($(this).attr('id')) {
        case "open": text = 'O Mercado-Minecraft é aberto a todos que querem comprar ou publicar plugins, tendo sistemas abertos, interativos e completamente seguros.'; break;
        case "host": text = 'Graças aos nossos sistemas de segurança \'multi-thread\' seus plugins nunca terão problemas para rodar por queda ou lentidão.'; break;
        case "payment": text = 'O sistema foi todo projetado para deixar o cliente seguro, então todo o sistema de pagamentos é feito por uma empresa antiga e experiente no mercado da tecnologia.'; break;
    }

    Swal.fire({
        text: text,
        confirmButtonText: 'Fechar',
        confirmButtonColor: '#6c5ce7'
    });

});

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function login(redirect) {
    $('.error').fadeOut();
    $('.success').fadeOut();

    if ($("input[name='email']").val() == "" || $("input[name='password']").val() == "") {
        $('.vermelho').text("Preencha todos os campos.");
        $('.error').fadeIn();
        return
    }

    if ($("input[name='password']").val().length < 5) {
        $('.vermelho').text("A sua senha precisa ter no mínimo 5 dígitos.");
        $('.error').fadeIn();
        return
    }

    $.ajax({
        type: 'POST',
        url: '/api/checkLogin',
        data: '{"email":"' + $("input[name='email']").val() + '","password":"' + $("input[name='password']").val() + '"}',
        success: function(data) {
            console.log(data)
            if (data.success == 'false') {
                if (data.banReason != undefined) {
                    $('.vermelho').text(data.banReason);
                    $('.error').fadeIn();
                } else {
                    $('.vermelho').text("O e-mail e/ou senha estão incorretos.\nPor favor, tente novamente.");
                    $('.error').fadeIn();
                }
            } else {
                $('.verde').text("Bem vindo, " + data.name + "!");
                $('.success').fadeIn();

                setTimeout(function() {
                    goTo(redirect)
                }, 500);
            }
        },
        error: function () {

            $('.vermelho').text("Ocorreu um erro.");
            $('.error').fadeIn();

        },
        dataType: 'json'
    });
}

function register() {

    $('.cadastrar').attr('disabled', 'true');
    $('.error').fadeOut();
    $('.success').fadeOut();

    if ($("input[name='email']").val() == "" || $("input[name='password']").val() == "") {
        $('.vermelho').text("Preencha todos os campos.");
        $('.error').fadeIn();
        return
    }

    if ($("input[name='password']").val().length < 5) {
        $('.vermelho').text("A sua senha precisa ter no mínimo 5 dígitos.");
        $('.error').fadeIn();
        return
    }

    $.ajax({
        type: 'POST',
        url: '/api/register',
        data: '{"username":"' + $("input[name='username']").val() + '","email":"' + $("input[name='email']").val() + '","password":"' + $("input[name='password']").val() + '","captcha":"'+$("div.h-captcha > iframe").attr('data-hcaptcha-response')+'"}',
        success: function(data) {
            console.log(data)
            if (data.success == 'false') {

                switch (data.error) {
                  case 0:
                    $('.vermelho').text("E-Mail inválido.");
                    break;
                   case 1:
                    $('.vermelho').text("E-Mail já cadastrado.");
                    break;
                  case 2:
                    $('.vermelho').text("Nome já cadastrado.");
                    break;
                  case 3:
                    $('.vermelho').text("Resolva o captcha.");
                    break;
                  default:
                    $('.vermelho').text("Não foi possível concluir o seu cadastro.");
                }

                $('.error').fadeIn();
                $('.cadastrar').attr('disabled', 'false');
           } else {
                $('.verde').text("Bem vindo, " + data.name + "!");
                $('.success').fadeIn();

                setTimeout(function() {
                    goTo('/')
                }, 500);
            }
        },
        dataType: 'json'
    });
}

async function editLicense(id, oldIP, pluginName, pluginID, redirect = '/') {
    const {
        value: ip
    } = await Swal.fire({
        title: 'Digite o IP',
        footer: '<center><a style="color:#6c5ce7" onclick="goTo(\'https://mercado-minecraft.com.br/produtos/' + pluginID + '/detalhes\')">Clique aqui para avaliar o Plugin.</button>' +
            ' | <a style="color:#6c5ce7" onclick="transferLicense(\'' + id + '\', \'' + pluginName + '\', \'' + redirect + '\')">Clique aqui para transferir a Licença.</button></center>',
        icon: 'question',
        confirmButtonText: 'Salvar',
        showCancelButton: true,
        input: 'text',
        inputValue: oldIP,
        confirmButtonColor: '#6c5ce7',
        inputValidator: (value) => {
            if (!value) {
                return 'IP Inválido.'
            }
        }
    })

    if (ip == undefined) {
        return;
    }

    $.ajax({
        type: 'POST',
        url: '/api/updateIP',
        data: '{"id":"' + id + '","ip":"' + ip + '"}',
        success: function(data) {
            console.log(data)
            if (data.success == 'false') {
                Swal.fire({
                    text: 'Não foi possível atualizar o IP...',
                    icon: 'error',
                    confirmButtonText: 'Ok',
                    confirmButtonColor: '#6c5ce7'
                });
            } else {
                Swal.fire({
                    text: 'O IP foi atualizado',
                    icon: 'success',
                    confirmButtonText: 'Ok',
                    confirmButtonColor: '#6c5ce7'
                }).then(function() {
                    location.href = redirect;
                }, function(dismiss) {
                    if (dismiss == 'cancel') {
                        location.href = redirect;
                    }
                });
            }
        },
        dataType: 'json'
    });
}

var childName = "";
var child = "";

function changeChild(newChild, newChildName) {
    child = newChild;
    childName = newChildName;

    $('.childText').html('Em resposta a <a href="/perfil/' + childName + '" style="text-decoration: none" class="seconds">@' + childName + '</button>');
}

function addReview(id) {

    $.ajax({
        type: 'POST',
        url: '/api/addReview',
        data: '{"id":"' + id + '","stars":' + $('[name=rating]:checked').val() + '}',
        success: function(data) {
            console.log(data)
            if (data.success == 'false') {
                Swal.fire({
                    text: 'Não foi possível publicar sua avaliação.',
                    icon: 'error',
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true
                });
            } else {
                Swal.fire({
                    text: 'Sua avaliação foi publicada.',
                    icon: 'success',
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true
                }).then(function() {
                    location.reload();
                }, function(dismiss) {
                    if (dismiss == 'cancel') {
                        location.reload();
                    }
                });
            }
        },
        dataType: 'json'
    });

}

function addComment(id) {

    $.ajax({
        type: 'POST',
        url: '/api/addComment',
        data: '{"id":"' + id + '","text":"' + $('.searchInput').val().replace('/"/g', '\"') + '","child":"' + child + '"}',
        success: function(data) {
            console.log(data)
            if (data.success == 'false') {
                Swal.fire({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 1000,
                    timerProgressBar: true,
                    text: 'Não foi possível publicar seu comentário.' + data.message,
                    icon: 'error'
                });
            } else {
                $('.searchInput').val("");
                Swal.fire({
                    text: 'Seu comentário foi publicado.',
                    icon: 'success',
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 1000,
                    timerProgressBar: true
                }).then(function() {
                    location.reload();
                }, function(dismiss) {
                    if (dismiss == 'cancel') {
                        location.reload();
                    }
                });
            }
        },
        dataType: 'json'
    });

}

function editComment(id, plugin) {
    var content = $('[data=' + id + '] .cPDTd-conteudo').html();
    $('[data=' + id + '] .cPDTd-conteudo').html('<textarea class="searchInput" placeholder="Escreva um comentário" style="margin: 0px; width: 716px; height: 125px;">' + content + '</textarea><div style="float:right"><div class="cPDTh-botoes"><center> <button class="botao btn-azul p12" onclick="addComment(\'' + plugin + '\')"> Editar comentário <ion-icon name="arrow-forward"></ion-icon></button> <br> <button class="botao btn-azul p12" onclick="cancelEdit(\'{{id}}\')"> Cancelar <ion-icon name="close"></ion-icon> </button></center></div></div>')
}

async function transferLicense(id, stars, review, oldIP, pluginName, redirect = '/') {
    const {
        value: email
    } = await Swal.fire({
        title: 'Digite o E-Mail de quem vai receber a licença',
        icon: 'question',
        confirmButtonText: 'Enviar',
        showCancelButton: true,
        input: 'email',
        confirmButtonColor: '#6c5ce7',
        inputValidator: (value) => {
            if (!value) {
                return 'E-Mail Inválido.'
            }
        }
    })

    if (email == undefined) {
        return;
    }

    $.ajax({
        type: 'POST',
        url:'/api/transferLicense',
        data: '{"id":"' + id + '","email":"' + email + '"}',
        success: function(data) {
            console.log(data)
            if (data.success == 'false') {
                Swal.fire({
                    text: 'Não foi possível transferir a licença...',
                    icon: 'error',
                    confirmButtonText: 'Ok',
                    confirmButtonColor: '#6c5ce7'
                });
            } else {
                Swal.fire({
                    text: 'Licença transferida para ' + data.name + '!',
                    icon: 'success',
                    confirmButtonText: 'Ok',
                    confirmButtonColor: '#6c5ce7'
                }).then(function() {
                    location.href = redirect;
                }, function(dismiss) {
                    if (dismiss == 'cancel') {
                        location.href = redirect;
                    }
                });
            }
        },
        dataType: 'json'
    });
}

function checkCoupon(link) {
    goTo(link + $("#cupom").val());
}

function showAlert(message) {
    Swal.fire({
        title: message,
        confirmButtonText: 'Ok',
        confirmButtonColor: '#6c5ce7'
    })
}

$('.licenseID').click(function () {

    copyToClipboard($(this).html());

    Swal.fire({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000,
      timerProgressBar: true,
      icon: 'success',
      title: 'Licença copiada!'
    })

});

function copyToClipboard(string) {
    var $temp = $("<input>");
    $("body").append($temp);
    $temp.val(string).select();
    document.execCommand("copy");
    $temp.remove();
}

var regex = new RegExp("(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\\])");

function editUser(avatar) {

    Swal.fire({
        icon: 'question',
        html: 'O que você deseja alterar?',
        cancelButtonText: 'E-Mail',
        cancelButtonColor: '#6c5ce7',
        showCancelButton: true,
        confirmButtonText: 'Foto',
        confirmButtonColor: '#6c5ce7'
    }).then(function(result) {

        if (result.dismiss == "cancel") {
            Swal.fire({
                icon: 'question',
                html: 'Coloque seu E-Mail do MercadoPago.',
                input: 'email',
                inputValue: '',
                cancelButtonText: 'Cancelar',
                cancelButtonColor: '#EE2C2C',
                showCancelButton: true,
                confirmButtonText: 'Atualizar e-mail',
                confirmButtonColor: '#6c5ce7',
                inputValidator: (value) => {
                    if (!value) return 'Você precisa escrever algo.'
                    if (!regex.exec(value)) return 'Você precisa escrever um email.'

                    updateProfile('email', value);
                }
            });
            return;
        }

        Swal.fire({
            icon: 'question',
            html: 'Coloque um URL do <a href="https://imgur.com/" target="_blank" class="seconds">Imgur</a> para sua foto.',
            input: 'text',
            inputValue: avatar,
            cancelButtonText: 'Cancelar',
            cancelButtonColor: '#EE2C2C',
            showCancelButton: true,
            confirmButtonText: 'Atualizar foto',
            confirmButtonColor: '#6c5ce7',
            inputValidator: (value) => {
                if (!value) return 'Você precisa escrever algo.'
                if (!value.startsWith('https://i.imgur.com') && !value.startsWith('https://i.imgur.com') && !value.startsWith('https://www.i.imgur.com') && !value.startsWith('https://www.i.imgur.com')) return 'Você precisa escrever um URL valido.'
                if (!value.endsWith('.jpg') && !value.endsWith('.png')) return 'Você precisa escrever um URL / Arquivo valido.'

                updateProfile('avatar', value);
            }
        });

    });

}

function updateProfile(type, value) {

    $.ajax({
            type: 'POST',
            url: '/api/updateProfile',
            data: '{"type":"' + type + '","value":"' + value + '"}',
            success: function(data) {
                console.log(data)
                if (data.success == 'false') {
                    Swal.fire({
                        text: 'Não foi possível atualizar o seu perfil...',
                        icon: 'error',
                        confirmButtonText: 'Ok',
                        confirmButtonColor: '#6c5ce7'
                    });
                } else {
                    Swal.fire({
                        text: 'Perfil atualizado!',
                        icon: 'success',
                        confirmButtonText: 'Ok',
                        confirmButtonColor: '#6c5ce7'
                    }).then(function() {
                        location.reload();
                    }, function(dismiss) {
                        if (dismiss == 'cancel') {
                            location.reload();
                        }
                    });
                }
            },
            dataType: 'json'
        });

}
