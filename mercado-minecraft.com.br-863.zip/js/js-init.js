$(function() {

    if (true == false && Cookies.get('DEVSHOP_POPUP') == undefined) {
        Swal.fire({
            html: '<img src="https://static.wikia.nocookie.net/minecraft_gamepedia/images/9/9d/Xmas_chest.png" style="float: left;width: 150px;margin-left: -40px;margin-top: 15px;margin-bottom: 15px;margin-right: 12px;"><h2 style="text-align: justify;">Feliz natal!</h2><p style="text-align: justify;">Aqui no <strong>Mercado-Minecraft</strong> o <strong>Natal</strong> começa mais cedo e termina mais tarde do dia <strong>01/12/2020</strong> até o dia <strong>31/01/2021</strong> o cupom <strong>NATAL15</strong> vai estar disponível para <strong>Compras e Encomendas</strong>.<br>Não deixe o <strong>Grinch</strong> roubar seus jogadores, venha já reformar seu servidor no <strong>Mercado-Minecraft</strong>.</p></div><br> <a type="button" class="swal2-confirm swal2-styled" aria-label="" style="display: inline-block; background-color: rgb(108, 92, 231); border-left-color: rgb(108, 92, 231); border-right-color: rgb(108, 92, 231);" href="/encomendar">Encomendar</a><a type="button" class="swal2-confirm swal2-styled" aria-label="" style="display: inline-block; background-color: rgb(108, 92, 231); border-left-color: rgb(108, 92, 231); border-right-color: rgb(108, 92, 231);" href="/produtos">Ver Produtos</a>',
            showConfirmButton: false,
            showCloseButton: true,
            width: '650px'
        });
        Cookies.set('DEVSHOP_POPUP', 'true', {
            expires: 2,
            path: '/'
        });
    }

});
